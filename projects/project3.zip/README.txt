1. Taewoo Kim
2. N/A
3. 1 hour
4. NONE